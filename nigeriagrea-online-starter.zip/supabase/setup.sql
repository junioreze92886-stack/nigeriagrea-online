-- Run this in Supabase SQL Editor before launch.
create extension if not exists pgcrypto;

create table if not exists public.products (
 id uuid primary key default gen_random_uuid(),
 title text not null,
 description text not null,
 category text not null,
 price_kobo integer not null check (price_kobo >= 10000),
 cover_url text,
 delivery_path text,
 active boolean not null default true,
 created_at timestamptz not null default now()
);
create table if not exists public.orders (
 id uuid primary key default gen_random_uuid(),
 product_id uuid not null references public.products(id),
 customer_email text not null,
 paystack_reference text unique not null,
 status text not null default 'pending' check (status in ('pending','paid','fulfilled','refunded')),
 amount_kobo integer not null,
 paid_at timestamptz,
 created_at timestamptz not null default now()
);
alter table public.products enable row level security;
alter table public.orders enable row level security;
-- Public visitors can only see published product fields. Do not expose delivery_path in public queries.
drop policy if exists "Public can view active products" on public.products;
create policy "Public can view active products" on public.products for select using (active = true);
-- Admin writes happen server-side in a production admin API, or via carefully configured admin policies.
-- Do NOT enable public insert/update/delete policies on products or orders.
-- Create a private Storage bucket named product-files. Covers may be public; delivery files must remain private.
insert into storage.buckets (id,name,public) values ('product-files','product-files',false) on conflict (id) do nothing;
-- NOTE: this starter admin UI needs storage policies and secure server-side admin authorization before production.
