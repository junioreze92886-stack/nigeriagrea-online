 "use client";
import { useEffect, useMemo, useState } from "react";
import { supabasePublic } from "@/lib/supabase";

type Product = { id:string; title:string; description:string; category:string; price_kobo:number; cover_url:string|null; delivery_url?:string|null; active?:boolean };
const categories = ["All products","Facebook tools","Instagram tools","Social media tools","Design & templates","Digital guides","Other digital products"];
const naira = (kobo:number) => new Intl.NumberFormat("en-NG",{style:"currency",currency:"NGN",maximumFractionDigits:0}).format(kobo/100);
export default function Home() {
  const [products,setProducts] = useState<Product[]>([]);
  const [category,setCategory] = useState("All products");
  const [query,setQuery] = useState("");
  const [loading,setLoading] = useState(true);
  const [notice,setNotice] = useState("");
  useEffect(() => {
    try {
      const sb = supabasePublic();
      sb.from("products").select("id,title,description,category,price_kobo,cover_url,active").eq("active",true).order("created_at",{ascending:false})
        .then(({data,error}) => { if(error) setNotice("Connect Supabase and run the setup SQL to load live products."); else setProducts((data||[]) as Product[]); setLoading(false); });
    } catch { setNotice("Preview mode: connect Supabase to publish your product catalogue."); setLoading(false); }
  },[]);
  const shown = useMemo(()=>products.filter(p=>(category==="All products"||p.category===category) && (p.title+" "+p.description+" "+p.category).toLowerCase().includes(query.toLowerCase())),[products,category,query]);
  async function buy(p:Product) {
    setNotice("");
    const email=window.prompt("Enter your email to receive your order confirmation:");
    if(!email) return;
    try {
      const res=await fetch("/api/checkout",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({productId:p.id,email})});
      const data=await res.json();
      if(!res.ok) throw new Error(data.error||"Could not start checkout.");
      window.location.href=data.authorization_url;
    } catch(e) { setNotice(e instanceof Error?e.message:"Checkout is not configured yet."); }
  }
  return <main>
    <div className="topline"><span>🇳🇬 Made for Nigeria</span><span>Secure digital checkout · Prices in NGN</span></div>
    <header className="header">
      <a className="brand" href="#"><span className="brandmark"><span>NG</span></span><span><b>Nigeriagrea<span>.online</span></b><small>YOUR DIGITAL MARKETPLACE</small></span></a>
      <nav><a href="#products">Shop</a><a href="#how">How it works</a><a href="#contact">Support</a><a className="adminlink" href="/admin">Admin ↗</a></nav>
    </header>
    <section className="hero">
      <div className="hero-copy"><div className="eyebrow"><i/> THE NIGERIAN DIGITAL MARKETPLACE</div>
        <h1>Useful digital tools.<br/><em>Simple and secure.</em></h1>
        <p>Discover digital guides, creative assets, social media tools and online services. Pay in naira and get eligible purchases delivered digitally.</p>
        <a className="primary" href="#products">Explore products <span>→</span></a>
        <div className="trust"><span>✓</span> Clear prices <span>✓</span> Digital delivery <span>✓</span> Naira checkout</div>
      </div>
      <div className="hero-art"><div className="sun"></div><div className="artcard"><div className="flag"><i></i><i></i><i></i></div><div className="artbig">NG<span>.</span></div><div className="artsmall">CREATE · GROW · CONNECT</div><div className="orbit o1"></div><div className="orbit o2"></div></div><div className="float-tag">₦ <b>NGN</b><small>LOCAL PAYMENTS</small></div><div className="green-dot"></div></div>
    </section>
    <section className="stats"><div><b>01</b><span>Browse the catalogue</span></div><div><b>02</b><span>Pay securely in naira</span></div><div><b>03</b><span>Receive your purchase</span></div></section>
    <section id="products" className="catalogue">
      <div className="sectionhead"><div><div className="eyebrow">THE COLLECTION</div><h2>Find your next <em>digital tool.</em></h2><p>Explore the latest products listed by our store team.</p></div><label className="search"><span>⌕</span><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search products..." /></label></div>
      <div className="filters">{categories.map(c=><button key={c} onClick={()=>setCategory(c)} className={category===c?"selected":""}>{c}</button>)}</div>
      {notice&&<div className="notice">{notice}</div>}
      {loading?<div className="empty">Loading catalogue…</div>:shown.length===0?<div className="empty"><div className="emptyicon">✳</div><h3>Your next favourite tool belongs here.</h3><p>{products.length===0?"Products will appear here after you configure the store and add items in the admin area.":"No products match your search. Try another category or keyword."}</p><a href="/admin">Store admin →</a></div>:
      <div className="productgrid">{shown.map(p=><article className="product" key={p.id}><div className="cover">{p.cover_url?<img src={p.cover_url} alt={p.title}/>:<div className="coverplaceholder">NG<span>.</span></div>}<span className="catpill">{p.category}</span></div><div className="productbody"><h3>{p.title}</h3><p>{p.description}</p><div className="productfoot"><b>{naira(p.price_kobo)}</b><button onClick={()=>buy(p)}>Buy now ↗</button></div></div></article>)}</div>}
    </section>
    <section id="how" className="how"><div className="eyebrow">STRAIGHTFORWARD BY DESIGN</div><h2>From discovery to delivery.</h2><div className="steps"><div><span>01</span><h3>Choose a product</h3><p>Read the description and price before you buy.</p></div><div><span>02</span><h3>Pay securely</h3><p>Checkout is handled by Paystack. Never send your PIN or OTP to anyone.</p></div><div><span>03</span><h3>Get your item</h3><p>After payment verification, eligible digital files can be made available securely.</p></div></div></section>
    <footer id="contact"><a className="brand" href="#"><span className="brandmark"><span>NG</span></span><span><b>Nigeriagrea<span>.online</span></b><small>YOUR DIGITAL MARKETPLACE</small></span></a><p>Digital products for people building online.</p><div><a href="mailto:support@nigeriagrea.online">Contact support</a><span>© {new Date().getFullYear()} Nigeriagrea.online</span></div><small className="legal">Only list products and services you own or are authorized to resell. This marketplace does not support selling account passwords, login credentials, or accounts in violation of platform rules.</small></footer>
  </main>;
}