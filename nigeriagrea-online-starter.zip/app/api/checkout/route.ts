import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
export async function POST(req:Request){
 try{
  const {productId,email:customerEmail}=await req.json();
  if(!productId)return NextResponse.json({error:"Product is required."},{status:400});
  const url=process.env.NEXT_PUBLIC_SUPABASE_URL, key=process.env.SUPABASE_SERVICE_ROLE_KEY, paystack=process.env.PAYSTACK_SECRET_KEY;
  if(!url||!key||!paystack)return NextResponse.json({error:"Checkout is not configured. Add Supabase and Paystack environment variables."},{status:503});
  const sb=createClient(url,key);const {data:p,error}=await sb.from("products").select("id,title,description,price_kobo,active").eq("id",productId).single();
  if(error||!p||!p.active)return NextResponse.json({error:"Product not found."},{status:404});
  const origin=process.env.NEXT_PUBLIC_SITE_URL||new URL(req.url).origin;
  if(!customerEmail.includes("@"))return NextResponse.json({error:"A valid customer email is required. Checkout form setup is required before launch."},{status:400});
  const init=await fetch("https://api.paystack.co/transaction/initialize",{method:"POST",headers:{"Authorization":`Bearer ${paystack}`,"Content-Type":"application/json"},body:JSON.stringify({email:customerEmail,amount:p.price_kobo,currency:"NGN",callback_url:`${origin}/payment/verify`,metadata:{product_id:p.id,product_title:p.title}})});
  const data=await init.json();if(!init.ok||!data.status)return NextResponse.json({error:data.message||"Paystack checkout failed."},{status:502});
  const {error:orderErr}=await sb.from("orders").insert({product_id:p.id,customer_email:customerEmail,paystack_reference:data.data.reference,status:"pending",amount_kobo:p.price_kobo});
  if(orderErr)return NextResponse.json({error:"Could not create order record."},{status:500});
  return NextResponse.json({authorization_url:data.data.authorization_url});
 }catch{return NextResponse.json({error:"Invalid checkout request."},{status:400})}
}