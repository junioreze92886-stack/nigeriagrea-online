import {NextResponse} from "next/server";
import {createClient} from "@supabase/supabase-js";
export async function POST(req:Request){
 try{
  const {reference}=await req.json();if(typeof reference!=="string"||!reference)return NextResponse.json({message:"Missing payment reference."},{status:400});
  const secret=process.env.PAYSTACK_SECRET_KEY,url=process.env.NEXT_PUBLIC_SUPABASE_URL,key=process.env.SUPABASE_SERVICE_ROLE_KEY;
  if(!secret||!url||!key)return NextResponse.json({message:"Payment verification is not configured."},{status:503});
  const verify=await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`,{headers:{Authorization:`Bearer ${secret}`}});
  const result=await verify.json();if(!verify.ok||!result.status||result.data?.status!=="success")return NextResponse.json({message:"Payment is not confirmed. If you were charged, contact support."},{status:400});
  const sb=createClient(url,key);const {data:order,error}=await sb.from("orders").select("id,amount_kobo,product_id,status").eq("paystack_reference",reference).single();
  if(error||!order)return NextResponse.json({message:"Payment received but order record was not found. Contact support."},{status:404});
  if(Number(result.data.amount)!==Number(order.amount_kobo)||result.data.currency!=="NGN")return NextResponse.json({message:"Payment amount did not match the order. Contact support."},{status:400});
  if(order.status!=="paid"){const {error:updateErr}=await sb.from("orders").update({status:"paid",paid_at:new Date().toISOString()}).eq("id",order.id);if(updateErr)return NextResponse.json({message:"Payment verified, but order update failed. Contact support."},{status:500});}
  return NextResponse.json({message:"Payment verified successfully. Your order is confirmed. Delivery access setup is required for automatic file delivery."});
 }catch{return NextResponse.json({message:"Could not verify payment."},{status:400})}
}