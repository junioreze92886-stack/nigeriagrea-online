import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "Nigeriagrea.online — Digital Marketplace",
  description: "Discover useful digital tools, creative assets and online services from Nigeria.",
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}