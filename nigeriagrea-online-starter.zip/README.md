# Nigeriagrea.online — deployable starter

A Nigerian-naira digital marketplace starter using Next.js, Supabase and Paystack. The UI includes category filters, product cards, a product admin screen, and payment initialization/verification API routes.

## Important before launch

This is a **starter project**, not a fully production-hardened store yet. Do not accept live payments until you finish the checklist below. The storefront asks for a customer email at checkout. Product admin storage/write permissions and secure delivery download links still need production hardening. The starter intentionally does not support selling social-media account passwords, login credentials, or accounts in violation of platform rules. Use it for lawful digital products, design assets, templates, guides, and authorized services.

## 1. Install and run

1. Install Node.js 20 or newer.
2. Extract this ZIP, open a terminal in the project folder, and run:
   ```bash
   npm install
   cp .env.example .env.local
   npm run dev
   ```
3. Open `http://localhost:3000`.

## 2. Configure Supabase

1. Create a project at https://supabase.com.
2. Copy the Project URL and anon key into `.env.local`.
3. Copy `supabase/setup.sql` into Supabase **SQL Editor** and run it.
4. In Supabase Authentication, create your admin user with your email and a strong password.
5. Create/configure storage policies and a secure server-side admin API before publishing. Never expose the Supabase service-role key in any `NEXT_PUBLIC_` variable.
6. Set `ADMIN_EMAIL` to your admin email. The included admin page is a UI starter; its admin authorization must be completed securely before production use.

## 3. Configure Paystack

1. Create/verify your merchant account at https://paystack.com.
2. Add `PAYSTACK_SECRET_KEY` from Paystack test mode to `.env.local` for testing.
3. Set `NEXT_PUBLIC_SITE_URL=http://localhost:3000` locally.
4. Complete the customer email checkout prompt in `app/page.tsx` and pass that email to `/api/checkout`.
5. Test successful, failed, cancelled, and duplicate payment cases in test mode. Only use your live secret key on the deployed server after your account is approved.
6. Implement a Paystack webhook with signature verification before relying on asynchronous payment confirmation.

## 4. Deploy to Vercel

1. Push the extracted project to a private GitHub repository.
2. Import the repository at https://vercel.com/new.
3. Add the environment variables from `.env.example` in Vercel Project Settings → Environment Variables.
4. Use your production domain as `NEXT_PUBLIC_SITE_URL`, deploy, and test again with Paystack test mode.
5. Replace test keys with live keys only after the full checkout, order, delivery, and admin security workflow is complete.

## Bank transfer details

You provided two transfer destinations:
- EMEKA SOLOMON EZE — account ending **9774**
- EMEKA SOLOMON EZE (OPay) — account ending **0269**

For safety, this starter does not display these as proof of payment or automatically mark an order paid from a screenshot. Manual transfers need an admin reconciliation step. For automated checkout, Paystack verifies payment server-side. Add full account details to a public payment page only if you intentionally want them public.

## Logo / branding

The site uses a green-and-white Nigerian-inspired NG brand mark. The uploaded landmark photo is included in `public/landmark-reference.jpg` as a reference asset; you can use it as a banner or replace the NG mark with an edited/cropped version if desired.
